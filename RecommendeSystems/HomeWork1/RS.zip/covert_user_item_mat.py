import pandas as pd
import numpy as np
import warnings
import random
warnings.filterwarnings('ignore')


def process_bar(percent, start_str='', end_str='100%', total_length=0):
    bar = ''.join(["\033[31m%s\033[0m"%'   '] * int(percent * total_length)) + ''
    bar = '\r' + start_str + bar.ljust(total_length) + ' {:0>4.1f}%|'.format(percent*100) + end_str
    print(bar, end='', flush=True)


def split_data(data, m, k, seed):
    train = pd.DataFrame()
    test = pd.DataFrame()

    random.seed(seed)
    for index, row in data.iterrows():
        process_bar(index / len(data))
        train_row = row.copy()
        test_row = row.copy()

        for index_, item in row.iteritems():
            if not item:
                continue

            if not random.randint(0, m/k):
                test_row[index_] = 0
            else:
                train_row[index_] = 0

        train = train.append(train_row)
        test = test.append(test_row)
    return train, test


def covert_user_item_mat(data):
    data_mat = pd.DataFrame()
    length = len(data)
    for index, row in data.iterrows():

        u_id = row["UserID"]
        m_id = row["MovieID"]
        rating = row["Rating"]

        movie_ids = data_mat.columns
        if u_id not in data_mat.index:
            new_user = pd.Series(np.zeros(len(movie_ids)), index=movie_ids, name=u_id)
            data_mat = data_mat.append(new_user)

        user_ids = data_mat.index
        if m_id not in data_mat.columns:
            new_movie = pd.Series(np.zeros(len(user_ids)), index=user_ids, name=m_id)
            new_movie[u_id] = rating
            data_mat[m_id] = new_movie
        else:
            data_mat.loc[u_id][m_id] = rating

    data_mat = data_mat.reindex(sorted(data_mat.columns), axis=1)

    return data_mat


data = pd.read_table('data/data.csv', sep=",")
data = data.sample(n=10)

u_i_mat = covert_user_item_mat(data)
u_i_mat.to_csv('data/test/data_mat.csv', header=True, index=True)
# u_i_mat = pd.read_csv('data/data_mat.csv')

train_mat, test_mat = split_data(u_i_mat, 8, 2, 1)

train_mat.to_csv('data/test/data_mat_train.csv', header=True, index=True)
test_mat.to_csv('data/test/data_mat_test.csv', header=True, index=True)
# train_mat = pd.read_csv('data/data_mat_train.csv')
# test_mat = pd.read_csv('data/data_mat_test.csv').loc[1].sum()

print(train_mat)
print(test_mat)
