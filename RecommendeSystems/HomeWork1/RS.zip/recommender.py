import pandas as pd
import numpy as np
import warnings
import random
from numpy import linalg as la
warnings.filterwarnings('ignore')
data = pd.read_table('data/data.csv', sep=",", index_col="UserID")[:1000]


def process_bar(percent, start_str='', end_str='100%', total_length=0):
    bar = ''.join(["\033[31m%s\033[0m"%'   '] * int(percent * total_length)) + ''
    bar = '\r' + start_str + bar.ljust(total_length) + ' {:0>4.1f}%|'.format(percent*100) + end_str
    print(bar, end='', flush=True)


def eclud_sim(a, b):
    return 1.0/(1.0 + la.norm(a - b))

def pears_sim(a, b):
    if len(a) < 3:
        return 1.0
    return 0.5+0.5*np.corrcoef(a, b, rowvar=False)[0][1]

def cons_sim(a,b):
    num = float(a.dot(b))
    denom = la.norm(a) * la.norm(b)
    if not denom:
        return  0
    return 0.5+0.5*(num/denom)

def jaccard(a, b):
    return 1.0*(a*b).sum()/(a+b-a*b).sum()

class Recommender():
    sim = None
    data = None
    def similarity(self, x, distance):
        y = np.ones((len(x), len(x)))
        for i in range(len(x)):
            process_bar(i / len(x))
            for j in range(len(x)):
                y[i, j] = distance(x[i], x[j])
        return y

    def fit(self, x, distance=jaccard):
        self.data = x
        self.sim = self.similarity(x.values, distance)


    def recommend_item(self, user_row, sim_row):
        recommendations = []
        for index1, item1 in user_row.iteritems():
            for index2, item2 in sim_row.iteritems():
                if item2 !=0 and item1 == 0:
                    recommendations.append((index2, item2))
        recommendations.sort(key=lambda val: val[1], reverse=True)
        return recommendations

    def recommend_user_cf(self, user_id, N):
        a = self.sim[0][1:]
        sim_user_index = np.where(a==np.max(a))[0][0]

        # index = id
        user_row = self.data.loc[user_id]
        sim_row = self.data.loc[sim_user_index]


        return self.recommend_item(user_row, sim_row)[:N]

    def recommend_item_cf(self, user_id, N):
        user_clo = self.data[user_id]
        sim_items = []
        item_ids = self.data.index.tolist()
        for item_id, item in user_clo.iteritems():
            if item == 0:
                continue

            item_index = item_ids.index(item_id)
            a = self.sim[item_index]
            # 找最相似的物品
            sim_item_index = np.argsort(a)[-1]

            for sim_item_index in sim_item_indexs:
                # 不相似和自己跳过
                if not a[sim_item_index] or sim_item_index == item_index:
                    continue
                sim_item_id = item_ids[sim_item_index]
                sim_items.append((sim_item_id, ))

        return sim_items[:N]


    def recall(self, train, test, N=10):
        hit = 0
        totla_recall = 0
        totla_precision = 0
        for index, row in train.iterrows():
            process_bar(index / len(train))

            test_row = test.loc[index]

            if test_row.empty:
                continue

            res = self.recommend_user_cf(index)[:N]


            for res_item in res:
                if res_item[0] in test_row[test_row>0]:
                    hit += 1
            totla_recall += len(test_row[test_row>0])
            totla_precision += N
        return hit / (totla_recall * 1.0), hit / (totla_precision * 1.0)


train_mat = pd.read_csv('data/test/data_mat.csv', sep=",", index_col=0)
# test_mat = pd.read_csv('data/test/data_mat_test.csv', sep=",")

r = Recommender()
# r.fit(train_mat, cons_sim)
# print('\n', r.recommend_user_cf(1,10))
# print('\n', r.recall(train_mat, test_mat))

r.fit(train_mat.T, cons_sim)
print('\n', r.recommend_item_cf(2788,10))
# print('\n', r.recall(train_mat, test_mat))
