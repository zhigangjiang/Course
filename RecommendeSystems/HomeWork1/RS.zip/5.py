import pandas as pd
import numpy as np
from keras import Model
import keras.backend as K
from keras.layers import Embedding, Reshape, Input, Dot

ratings = pd.read_csv("data/ratings.csv", names=[
    "UserID",
    "MovieID",
    "Rating",
    "Timestamp"])

num_user = np.max(ratings["UserID"])
num_movie = np.max(ratings["MovieID"])
print(num_user, num_movie, len(ratings))

K.clear_session()


def Recmand_model(num_user, num_movie, k):
    input_uer = Input(shape=[None, ], dtype="int32")
    model_uer = Embedding(num_user + 1, k, input_length=1)(input_uer)
    model_uer = Reshape((k,))(model_uer)

    input_movie = Input(shape=[None, ], dtype="int32")
    model_movie = Embedding(num_movie + 1, k, input_length=1)(input_movie)
    model_movie = Reshape((k,))(model_movie)

    out = Dot(1)([model_uer, model_movie])
    model = Model(inputs=[input_uer, input_movie], outputs=out)
    model.compile(loss='mse', optimizer='Adam')
    model.summary()
    return model


model = Recmand_model(num_user, num_movie, 100)

train_user = ratings["UserID"].values
train_movie = ratings["MovieID"].values
train_x = [train_user, train_movie]
train_y = ratings["Rating"].values

# model.fit(train_x, train_y, batch_size=100, epochs=10)
# model.save_weights("model.h5")
model.load_weights("model.h5")
print(model.predict([[1], [2]]))
